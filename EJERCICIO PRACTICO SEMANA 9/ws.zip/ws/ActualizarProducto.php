<?php
//include('manto_producto.php');


$conexion = mysqli_connect('localhost','id16446080_servicetech_mjl','Mfca-3b-1234','id16446080_servicestech_a');
if(!$conexion){
    echo"Error de conexion";
}

//require 'manto_categorias.php';
$id = $_POST['id'];
$nombrepro = htmlspecialchars($_POST["nombrepro"],ENT_QUOTES);
$despro = htmlspecialchars($_POST["despro"],ENT_QUOTES);
$stock = $_POST["stock"];
$preciopro = $_POST["preciopro"];
$unidad = $_POST["unidad"];
$estadoproducto = $_POST["estadoproducto"];
$categoria = $_POST["categoria"];

$query ="UPDATE tb_productos SET id_producto='$id',nom_producto='$nombrepro',des_producto='$despro',stock='$stock',precio='$preciopro',unidad_medida='$unidad',estado_producto='$estadoproducto',categoria='$categoria' WHERE id_categoria = '$id'";
$resultado = mysqli_query($conexion,$query);

if($resultado){
    echo"Se actualizo correctamente";
}else{
    echo"No se actualizo";
}



?>