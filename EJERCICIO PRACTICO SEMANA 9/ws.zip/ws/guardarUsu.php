<?php
//include('manto_categorias.php');

//require 'manto_categorias.php';

$conexion = mysqli_connect('localhost','id16446080_servicetech_mjl','Mfca-3b-1234','id16446080_servicestech_a');
if(!$conexion){
    echo"Error de conexion";
}

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$clave = $_POST['clave'];
$tipo = $_POST['tipo'];
$estado = $_POST['estado'];
$pregunta = $_POST['pregunta'];
$respuesta = $_POST['respuesta'];

$query ="INSERT INTO tb_usuarios(id,nombre, apellidos, correo, usuario, clave, tipo, estado, pregunta, respuesta) values ('$id','$nombre','$apellidos','$correo','$usuario','$clave','$tipo','$estado','$pregunta','$respuesta')";
$resultado = mysqli_query($conexion,$query);

if($resultado){
    echo"Registrado correctamente";
}else{
    echo"No se registro";
}



?>