<?php
//include('manto_categorias.php');

//require 'manto_categorias.php';

$conexion = mysqli_connect('localhost','id16446080_servicetech_mjl','Mfca-3b-1234','id16446080_servicestech_a');
if(!$conexion){
    echo"Error de conexion";
}

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$estado = $_POST['estado'];


$query ="INSERT INTO tb_categorias(id_categoria,nom_categoria, estado_categoria) values ('$id','$nombre','$estado')";
$resultado = mysqli_query($conexion,$query);

if($resultado){
    echo"Categoria registrada correctamente";
}else{
    echo"No se registro la categoria, Ya existe";
 
}



?>