<?php
//include('main_class.php');

        include 'connection_db.php';
        $id = $_GET['id'];
        
        $consulta = "SELECT * from tb_productos where id_producto = '$id'";
        $resultado = $conexion -> query($consulta);
        
        while($fila=$resultado -> fetch_array()){
            $producto[] = array_map('utf8_encode', $fila);
        }
        echo json_encode($producto); 
        
        
        

?>