<?php
include('manto_categoria.php');
//require 'manto_categoria.php';
$id = $_POST['id'];
$nombre = htmlspecialchars($_POST["nombre"],ENT_QUOTES);
$estado = htmlspecialchars($_POST["estado"],ENT_QUOTES);
if (($id!="") and
    ($nombre!="") and 
    ($estado!="")) {
     	
    $resultado = Mantenimiento::guardar_Categorias($id, $nombre, $estado);

	if ($resultado==1) {
        header('Content-type: application/json; charset=utf-8');
        $json_string = json_encode(array("estado" => 1,"mensaje" => "Registro guardado correctamente."));
        echo $json_string;
        echo "Registro guardado...";
    } else {
        header('Content-type: application/json; charset=utf-8');
        $json_string = json_encode(array("estado" => 2,"mensaje" => "No se ha guardado nada."));
		echo $json_string;
    }
}
?>