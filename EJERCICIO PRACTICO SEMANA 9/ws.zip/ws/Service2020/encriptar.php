<?php
 
 $clave = "12345";

 echo $clave."<br>";
 echo md5($clave);



?>