<?php
//include 'connection_db.php';

$conexion = mysqli_connect('localhost','id16446080_servicetech_mjl','Mfca-3b-1234','id16446080_servicestech_a');
if(!$conexion){
    echo"Error de conexion";
}
$email=$_POST['email'];
$clave=$_POST['clave'];
$tipo=$_POST['tipo'];
//$usu_usuario="aroncal@gmail.com";
//$usu_password="12345678";

$query = "SELECT * FROM tb_usuarios WHERE correo='$email' AND clave='$clave' AND tipo='$tipo'";
$resultado = mysqli_query($conexion,$query);

if (!empty($resultado) && $resultado->num_rows > 0) {
         echo "Ingreso correctamente";   
}else{
    echo "Email o Contraseña incorrecta";
    
}

?>