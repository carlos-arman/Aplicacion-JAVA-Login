<?php
include('manto_categorias.php');
    /* $id = $_GET['id'];
    
     $consulta = "SELECT * from tb_categorias where id_categoria = '$id'";
     
     $resultado = $conexion -> query($consulta);
    
     
     while($fila=$resultado -> fetch_array()){
        
         $categoria[] = array_map('utf8_encode', $fila);
     }
  echo json_encode($categoria);
*/
if (isset($_GET["id"])){
 	$id = $_GET['id'];

	$resultado = Mantenimiento::getCategorias($id);
	//echo $retorno;
	if ($resultado) {
			
		//PRUEBA FUNCIONAL.
		//echo "1";   //solo esta línea para funcionamiento actual.
		$datos = array();
		$datos[] = array_map("utf8_encode", $resultado);
  		header('Content-type: application/json; charset=utf-8');
    //	$json_array = json_encode($datos);
		//echo $json_array;

    echo json_encode($datos, JSON_UNESCAPED_UNICODE);

	}else{ 
	    echo "No se encuentra";
        //envio un 0 para decirle a android que no existe el email.
        echo "0";                 //solo esta línea para funcionamiento actual. 
    } 
}
?>