<?php
    
//include('main_class.php');
 include 'connection_db.php';
    $idp = $_GET['idp'];
     
    $consulta = "SELECT * FROM tb_productos where id_producto = '$idp'";

     $resultado = $conexion -> query($consulta);
    
    $consulta->setFetchMode(PDO::FETCH_ASSOC);

    while($fila=$resultado -> fetch_array()){
    $producto[] = array_map('utf8_encode', $fila);
    }
    echo json_encode($producto);
        

?>