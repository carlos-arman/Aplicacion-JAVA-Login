<?php
//include('manto_producto.php');


$conexion = mysqli_connect('localhost','id16446080_servicetech_mjl','Mfca-3b-1234','id16446080_servicestech_a');
if(!$conexion){
    echo"Error de conexion";
}

//require 'manto_categorias.php';
$id = $_POST['id'];
$nombrepro = htmlspecialchars($_POST["nombrepro"],ENT_QUOTES);
$despro = htmlspecialchars($_POST["despro"],ENT_QUOTES);
$stock = $_POST["stock"];
$preciopro = $_POST["preciopro"];
$unidad = $_POST["unidad"];
$estadoproducto = $_POST["estadoproducto"];
$categoria = $_POST["categoria"];

$query ="INSERT INTO tb_productos(id_producto,nom_producto, des_producto, stock, precio, unidad_medida, estado_producto, categoria) values ('$id','$nombrepro','$despro','$stock','$preciopro','$unidad','$estadoproducto','$categoria')";
$resultado = mysqli_query($conexion,$query);

if($resultado){
    echo"Producto registrado correctamente";
}else{
    echo"No se registro";
}



?>